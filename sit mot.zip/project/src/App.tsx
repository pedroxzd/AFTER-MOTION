import React from 'react';
import { Video, Sparkles, Play, Package, Music, BookTemplate as Template, DollarSign, Users, Briefcase, ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-purple-950 to-black">
      {/* Navigation */}
      <nav className="bg-black/40 backdrop-blur-sm fixed w-full z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold text-white">After Motion</span>
            <div className="space-x-6">
              <a href="#about" className="text-white hover:text-purple-400 transition">Sobre o Curso</a>
              <a href="#instructor" className="text-white hover:text-purple-400 transition">Quem Sou Eu</a>
              <a href="#pricing" className="text-white hover:text-purple-400 transition">Preço</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Domine a Arte da Edição de Vídeo<br />
            <span className="text-purple-500">pelo Celular</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Transforme vídeos comuns em conteúdo viral! Aprenda técnicas profissionais 
            de edição mobile e destaque-se nas redes sociais com edições impressionantes.
          </p>
          <a href="#pricing" className="inline-flex items-center px-8 py-4 bg-purple-800 text-white rounded-full text-lg font-semibold hover:bg-purple-700 transition transform hover:scale-105">
            Adquirir Agora
            <ChevronRight className="ml-2" />
          </a>
        </div>
      </section>

      {/* Instructor Section */}
      <section id="instructor" className="py-20 px-6 bg-black/60">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Quem Sou Eu</h2>
          <div className="flex flex-col md:flex-row items-center gap-12">
            <img 
              src="https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=800&q=80" 
              alt="Instrutor"
              className="w-64 h-64 rounded-full object-cover border-4 border-purple-800"
            />
            <div className="max-w-2xl">
              <p className="text-gray-300 text-lg leading-relaxed">
                Meu nome é Pedro, sou editor de vídeo mobile há 5 anos, especializado em edição dinâmica 
                e profissional para redes sociais como TikTok, YouTube, Reels e Shorts. Já trabalhei com 
                diversos criadores de conteúdo e empresas, ajudando a transformar vídeos comuns em conteúdos 
                virais e impactantes.
                <br /><br />
                Se você quer aprender a editar como um profissional, do zero ao avançado, sem precisar de 
                um PC, está no lugar certo! 🎬🔥
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            O Que Você Vai Aprender 🎯
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Video className="w-8 h-8" />,
                title: "Edição para TikTok, Reels e Shorts",
                description: "Domine as técnicas específicas para cada plataforma"
              },
              {
                icon: <Play className="w-8 h-8" />,
                title: "Cortes e Transições Profissionais",
                description: "Aprenda transições suaves e impactantes"
              },
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Efeitos Especiais e Animações",
                description: "Crie efeitos cinematográficos impressionantes"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-black/40 backdrop-blur-sm rounded-xl p-6 hover:transform hover:scale-105 transition border border-purple-900/30">
                <div className="text-purple-500 mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonus Section */}
      <section className="py-20 px-6 bg-black/60 relative">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1599508704512-2f19efd1e35f?w=1600&q=80')] bg-center bg-cover bg-no-repeat"></div>
        <div className="container mx-auto relative">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Bônus Exclusivos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Package className="w-8 h-8" />,
                title: "Pack de Presets e Overlays",
                description: "Mais de 100 presets profissionais prontos para usar"
              },
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Efeitos Especiais Prontos",
                description: "Biblioteca com +50 efeitos especiais cinematográficos"
              },
              {
                icon: <Music className="w-8 h-8" />,
                title: "Pack de Áudio Premium",
                description: "Músicas e efeitos sonoros profissionais"
              },
              {
                icon: <Template className="w-8 h-8" />,
                title: "Templates Alight Motion",
                description: "20 templates exclusivos para acelerar suas edições"
              }
            ].map((bonus, index) => (
              <div key={index} className="bg-gradient-to-br from-purple-950 to-black rounded-xl p-6 border border-purple-800/30 backdrop-blur-sm">
                <div className="text-purple-500 mb-4">{bonus.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-2">{bonus.title}</h3>
                <p className="text-gray-300">{bonus.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Start Section */}
      <section className="py-20 px-6 relative">
        <div className="absolute inset-0 opacity-5 bg-[url('https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=1600&q=80')] bg-center bg-cover bg-no-repeat"></div>
        <div className="container mx-auto relative">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Por Que Começar Agora?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <Briefcase className="w-8 h-8" />,
                title: "Oportunidades de Emprego",
                description: "O mundo está cada vez mais digital, e a demanda por editores qualificados só aumenta"
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: "Crescimento nas Redes",
                description: "Edições profissionais aumentam significativamente suas chances de viralizar"
              },
              {
                icon: <DollarSign className="w-8 h-8" />,
                title: "Fonte de Renda",
                description: "Transforme sua habilidade em um negócio lucrativo"
              }
            ].map((reason, index) => (
              <div key={index} className="bg-gradient-to-br from-black to-purple-950 rounded-xl p-6 border border-purple-900/30 backdrop-blur-sm">
                <div className="text-purple-500 mb-4">{reason.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-2">{reason.title}</h3>
                <p className="text-gray-300">{reason.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6 bg-black/60">
        <div className="container mx-auto text-center">
          <div className="max-w-xl mx-auto bg-gradient-to-br from-black to-purple-950 rounded-2xl p-8 border border-purple-800/30">
            <h2 className="text-3xl font-bold text-white mb-6">Investimento</h2>
            <div className="mb-6">
              <span className="text-gray-300 line-through text-2xl">R$ 120,00</span>
              <div className="text-4xl font-bold text-white mt-2">
                R$ 67,00
                <span className="text-sm font-normal ml-2">à vista</span>
              </div>
            </div>
              <a href="https://pay.cakto.com.br/32vnzdn_312113" target="_blank" rel="noopener noreferrer">
  <button className="w-full bg-purple-800 text-white rounded-full py-4 px-8 text-lg font-semibold hover:bg-purple-700 transition transform hover:scale-105">
    Quero Começar Agora!
  </button>
</a>

        </div>
      </section>
    </div>
  );
}

export default App;